# RetinaGuard AI - Windows setup

## 1. Configure MongoDB Atlas
Open `.env` and replace:

MONGO_URL=mongodb+srv://YOUR_DB_USER:YOUR_DB_PASSWORD@cluster0.6oojjna.mongodb.net/?appName=Cluster0

with your real MongoDB Atlas connection string. Do not include the angle brackets.

Set the database name:

DB_NAME=retinaguard_ai

Also set your EMERGENT_LLM_KEY if you want live Gemini vision analysis. If it is left as the placeholder, scan analysis uses the built-in fallback/mock analysis.

## 2. Install dependencies
Open PowerShell in this project folder and run:

```powershell
yarn install
```

## 3. Start the website

```powershell
yarn dev
```

Open:

http://localhost:3000

Do NOT open http://0.0.0.0:3000 in the browser. `0.0.0.0` is only the server bind address.

## 4. Test registration
Create a user from the Sign Up page. The app stores users in MongoDB Atlas in the `users` collection and stores password hashes, not plain-text passwords.

## 5. If you changed .env while Next.js was running
Stop the server with Ctrl+C and restart:

```powershell
yarn dev
```
