'use client'

import { useState, useEffect, useRef, useMemo, useCallback } from 'react'
import { toast } from 'sonner'
import {
  LayoutDashboard, Users, ScanEye, FileText, BarChart3, Settings, LogOut,
  Search, Plus, Upload, Eye, Download, ChevronRight, User, Activity,
  AlertTriangle, AlertCircle, CheckCircle2, Clock, Loader2, ArrowLeft, Camera, Printer,
  FileSpreadsheet, Trash2, Edit, Zap, Layers, Info, ShieldCheck, Brain, Mail, Phone,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import {
  PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis,
  Tooltip, Legend, BarChart, Bar, CartesianGrid, AreaChart, Area,
} from 'recharts'

// ---- Constants -------------------------------------------------------------
const SEVERITIES = ['No DR', 'Mild', 'Moderate', 'Severe', 'Proliferative']
const SEVERITY_COLORS = {
  'No DR':        { bg: 'bg-emerald-100', text: 'text-emerald-800', ring: 'ring-emerald-500', hex: '#10b981', border: 'border-emerald-300' },
  'Mild':         { bg: 'bg-yellow-100',  text: 'text-yellow-800',  ring: 'ring-yellow-500',  hex: '#eab308', border: 'border-yellow-300' },
  'Moderate':     { bg: 'bg-orange-100',  text: 'text-orange-800',  ring: 'ring-orange-500',  hex: '#f97316', border: 'border-orange-300' },
  'Severe':       { bg: 'bg-red-100',     text: 'text-red-800',     ring: 'ring-red-500',     hex: '#ef4444', border: 'border-red-300' },
  'Proliferative':{ bg: 'bg-rose-200',    text: 'text-rose-900',    ring: 'ring-rose-600',    hex: '#be123c', border: 'border-rose-400' },
}
const LESION_COLORS = {
  microaneurysm: '#eab308',
  hemorrhage: '#ef4444',
  exudate: '#f97316',
  neovascularization: '#be123c',
  cotton_wool_spot: '#a855f7',
}

// ---- API helper ------------------------------------------------------------
async function api(path, opts = {}) {
  const res = await fetch(`/api${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Request failed' }))
    throw new Error(err.error || 'Request failed')
  }
  return res.json()
}

// ---- Small UI atoms --------------------------------------------------------
function SeverityBadge({ severity }) {
  const c = SEVERITY_COLORS[severity] || { bg: 'bg-slate-100', text: 'text-slate-700', border: 'border-slate-300' }
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${c.bg} ${c.text} ${c.border}`}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: c.hex }} />
      {severity}
    </span>
  )
}

function StatCard({ icon: Icon, label, value, sub, tone = 'teal' }) {
  const tones = {
    teal: 'from-teal-500 to-cyan-600',
    blue: 'from-blue-500 to-indigo-600',
    amber: 'from-amber-500 to-orange-600',
    emerald: 'from-emerald-500 to-teal-600',
  }
  return (
    <Card className="relative overflow-hidden border-slate-200">
      <div className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${tones[tone]}`} />
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{label}</p>
            <p className="text-3xl font-bold text-slate-900 mt-1">{value}</p>
            {sub && <p className="text-xs text-slate-500 mt-1">{sub}</p>}
          </div>
          <div className={`p-2.5 rounded-lg bg-gradient-to-br ${tones[tone]} text-white`}>
            <Icon className="w-5 h-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// ---- Login + Register View ------------------------------------------------
function AuthView({ onLogin }) {
  const [mode, setMode] = useState('login')  // 'login' | 'register' | 'forgot'
  return (
    <div className="min-h-screen flex bg-gradient-to-br from-slate-50 via-teal-50 to-cyan-50">
      <div className="hidden lg:flex flex-1 relative bg-gradient-to-br from-teal-700 via-teal-800 to-slate-900 p-12 items-center justify-center overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: 'radial-gradient(circle at 30% 20%, rgba(20,184,166,.4) 0%, transparent 40%), radial-gradient(circle at 70% 80%, rgba(6,182,212,.4) 0%, transparent 40%)'
        }} />
        <div className="relative z-10 max-w-md text-white">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center"><Eye className="w-6 h-6" /></div>
            <div>
              <div className="text-2xl font-bold tracking-tight">RetinaGuard</div>
              <div className="text-xs text-teal-200 uppercase tracking-widest">Clinical Decision Support</div>
            </div>
          </div>
          <h1 className="text-4xl font-bold leading-tight mb-4">diabetic retinopathy screening for the modern clinic.</h1>
          <p className="text-teal-100 leading-relaxed">Hybrid CNN ensemble — EfficientNet-B4, ResNet-50, DenseNet-121 — with Grad-CAM explainability, calibrated confidence, and human-in-the-loop review.</p>
          <div className="mt-10 grid grid-cols-3 gap-4">
            {[['97.6%','Accuracy'],['0.994','AUC'],['<3s','Inference']].map(([v,l]) => (
              <div key={l} className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-3">
                <div className="text-2xl font-bold">{v}</div>
                <div className="text-xs text-teal-200">{l}</div>
              </div>
            ))}
          </div>
          <p className="mt-10 text-xs text-teal-300/70">AI-assisted decision support tool — not a standalone diagnostic device. Final diagnosis must be confirmed by a licensed physician.</p>
        </div>
      </div>
      <div className="flex-1 flex items-center justify-center p-6 md:p-8 overflow-y-auto">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-2 mb-6 justify-center">
            <div className="w-10 h-10 rounded-lg bg-teal-700 text-white flex items-center justify-center"><Eye className="w-5 h-5" /></div>
            <div className="text-xl font-bold">RetinaGuard</div>
          </div>
          {mode === 'login' && <SignInCard onLogin={onLogin} onSwitch={setMode} />}
          {mode === 'register' && <SignUpCard onLogin={onLogin} onSwitch={setMode} />}
          {mode === 'forgot' && <ForgotPasswordCard onSwitch={setMode} />}
        </div>
      </div>
    </div>
  )
}

function GoogleButton() {
  const go = () => {
    const cb = `${window.location.origin}/auth/callback`
    window.location.assign(`https://auth.emergentagent.com/?redirect=${encodeURIComponent(cb)}`)
  }
  return (
    <Button type="button" onClick={go} variant="outline" className="w-full h-11 border-slate-300 hover:bg-slate-50 font-semibold">
      <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
      </svg>
      Continue with Google
    </Button>
  )
}

function SignInCard({ onLogin, onSwitch }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [errMsg, setErrMsg] = useState('')
  const [fieldErr, setFieldErr] = useState({})

  const submit = async (e) => {
    e.preventDefault(); setErrMsg(''); setFieldErr({})
    const errs = {}
    if (!email) errs.email = 'Please enter your email address.'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) errs.email = 'Please enter a valid email address.'
    if (!password) errs.password = 'Please enter your password.'
    if (Object.keys(errs).length) { setFieldErr(errs); return }
    setLoading(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      })
      const data = await res.json()
      if (!res.ok || !data.success) {
        setErrMsg(data.message || 'Invalid email or password.')
        return
      }
      toast.success(`Welcome back, ${data.user.firstName}`)
      onLogin(data.user)
    } catch (e) {
      setErrMsg('Unable to connect to the server. Please try again.')
    } finally { setLoading(false) }
  }

  return (
    <Card className="border-slate-200 shadow-xl">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl">Welcome back</CardTitle>
        <CardDescription>Sign in to continue to your RetinaGuard AI workspace.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-4">
          <GoogleButton />
          <div className="relative py-1">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-200" /></div>
            <div className="relative flex justify-center"><span className="bg-white px-3 text-xs text-slate-500 uppercase tracking-wider">or sign in with email</span></div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="li-email">Email address</Label>
            <Input id="li-email" type="email" placeholder="you@clinic.com" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" />
            {fieldErr.email && <p className="text-xs text-red-600">{fieldErr.email}</p>}
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between"><Label htmlFor="li-pw">Password</Label>
              <button type="button" onClick={() => onSwitch('forgot')} className="text-xs text-teal-700 font-medium hover:underline">Forgot password?</button>
            </div>
            <Input id="li-pw" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" />
            {fieldErr.password && <p className="text-xs text-red-600">{fieldErr.password}</p>}
          </div>
          {errMsg && <Alert className="border-red-200 bg-red-50"><AlertCircle className="w-4 h-4 text-red-600" /><AlertDescription className="text-red-800 text-sm">{errMsg}</AlertDescription></Alert>}
          <Button type="submit" disabled={loading} className="w-full h-11 bg-teal-700 hover:bg-teal-800">
            {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Signing in...</> : 'Sign In'}
          </Button>
          <p className="text-sm text-center text-slate-600 pt-2">Don't have an account?{' '}
            <button type="button" onClick={() => onSwitch('register')} className="text-teal-700 font-semibold hover:underline">Create an account</button>
          </p>
        </form>
      </CardContent>
    </Card>
  )
}

function SignUpCard({ onLogin, onSwitch }) {
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', phone: '', password: '', confirmPassword: '', role: 'Doctor' })
  const [errs, setErrs] = useState({})
  const [errMsg, setErrMsg] = useState('')
  const [loading, setLoading] = useState(false)
  const set = (k, v) => { setForm(f => ({ ...f, [k]: v })); setErrs(e => ({ ...e, [k]: null })) }

  const validate = () => {
    const e = {}
    if (!form.firstName || form.firstName.trim().length < 2) e.firstName = 'First name must be at least 2 characters.'
    if (!form.lastName) e.lastName = 'Last name is required.'
    if (!form.email) e.email = 'Email is required.'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email)) e.email = 'Please enter a valid email address.'
    if (!form.phone) e.phone = 'Phone number is required.'
    else if (!/^[+]?[\d\s\-()]{7,20}$/.test(form.phone)) e.phone = 'Please enter a valid phone number.'
    if (!form.password) e.password = 'Password is required.'
    else if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/.test(form.password))
      e.password = 'Password must contain at least 8 characters with uppercase, lowercase, number, and special character.'
    if (form.password !== form.confirmPassword) e.confirmPassword = 'Passwords do not match.'
    if (!form.role) e.role = 'Please select a role.'
    return e
  }

  const submit = async (ev) => {
    ev.preventDefault(); setErrMsg('')
    const e = validate(); setErrs(e)
    if (Object.keys(e).length) return
    setLoading(true)
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!res.ok || !data.success) {
        if (data.errors) setErrs(data.errors)
        else setErrMsg(data.message || 'Registration failed.')
        return
      }
      // Auto-login after successful registration
      const loginRes = await fetch('/api/auth/login', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: form.email, password: form.password }),
      })
      const loginData = await loginRes.json()
      if (loginRes.ok && loginData.success) {
        toast.success('Account created — welcome to RetinaGuard!')
        onLogin(loginData.user)
      } else {
        toast.success('Account created — please sign in.')
        onSwitch('login')
      }
    } catch { setErrMsg('Unable to connect to the server. Please try again.') } finally { setLoading(false) }
  }

  return (
    <Card className="border-slate-200 shadow-xl">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl">Create your RetinaGuard  account</CardTitle>
        <CardDescription>Create an account to securely manage your retinal screening records and reports.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-3.5">
          <GoogleButton />
          <div className="relative py-1">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-200" /></div>
            <div className="relative flex justify-center"><span className="bg-white px-3 text-xs text-slate-500 uppercase tracking-wider">or sign up with email</span></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1"><Label htmlFor="su-fn">First name</Label>
              <Input id="su-fn" value={form.firstName} onChange={e => set('firstName', e.target.value)} />
              {errs.firstName && <p className="text-xs text-red-600">{errs.firstName}</p>}</div>
            <div className="space-y-1"><Label htmlFor="su-ln">Last name</Label>
              <Input id="su-ln" value={form.lastName} onChange={e => set('lastName', e.target.value)} />
              {errs.lastName && <p className="text-xs text-red-600">{errs.lastName}</p>}</div>
          </div>
          <div className="space-y-1"><Label htmlFor="su-em">Email address</Label>
            <Input id="su-em" type="email" value={form.email} onChange={e => set('email', e.target.value)} />
            {errs.email && <p className="text-xs text-red-600">{errs.email}</p>}</div>
          <div className="space-y-1"><Label htmlFor="su-ph">Phone number</Label>
            <Input id="su-ph" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="+1 555 123 4567" />
            {errs.phone && <p className="text-xs text-red-600">{errs.phone}</p>}</div>
          <div className="space-y-1"><Label htmlFor="su-role">Role</Label>
            <Select value={form.role} onValueChange={v => set('role', v)}>
              <SelectTrigger id="su-role"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Doctor">Doctor</SelectItem>
                <SelectItem value="Clinician">Clinician</SelectItem>
                <SelectItem value="Patient">Patient</SelectItem>
              </SelectContent>
            </Select>
            {errs.role && <p className="text-xs text-red-600">{errs.role}</p>}</div>
          <div className="space-y-1"><Label htmlFor="su-pw">Password</Label>
            <Input id="su-pw" type="password" value={form.password} onChange={e => set('password', e.target.value)} />
            {errs.password ? <p className="text-xs text-red-600">{errs.password}</p> : <p className="text-[10px] text-slate-400">Min 8 chars · uppercase · lowercase · number · special character</p>}</div>
          <div className="space-y-1"><Label htmlFor="su-cpw">Confirm password</Label>
            <Input id="su-cpw" type="password" value={form.confirmPassword} onChange={e => set('confirmPassword', e.target.value)} />
            {errs.confirmPassword && <p className="text-xs text-red-600">{errs.confirmPassword}</p>}</div>
          {errMsg && <Alert className="border-red-200 bg-red-50"><AlertCircle className="w-4 h-4 text-red-600" /><AlertDescription className="text-red-800 text-sm">{errMsg}</AlertDescription></Alert>}
          <Button type="submit" disabled={loading} className="w-full h-11 bg-teal-700 hover:bg-teal-800 mt-2">
            {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Creating account...</> : 'Create Account'}
          </Button>
          <p className="text-sm text-center text-slate-600 pt-1">Already have an account?{' '}
            <button type="button" onClick={() => onSwitch('login')} className="text-teal-700 font-semibold hover:underline">Sign in</button>
          </p>
        </form>
      </CardContent>
    </Card>
  )
}

function ForgotPasswordCard({ onSwitch }) {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [loading, setLoading] = useState(false)
  const submit = async (e) => {
    e.preventDefault(); setLoading(true)
    try {
      await fetch('/api/auth/forgot-password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email }) })
      setSent(true)
    } finally { setLoading(false) }
  }
  return (
    <Card className="border-slate-200 shadow-xl">
      <CardHeader><CardTitle className="text-2xl">Reset your password</CardTitle><CardDescription>We'll email you instructions to set a new password.</CardDescription></CardHeader>
      <CardContent>
        {sent ? (
          <div className="text-center py-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
            <p className="text-sm text-slate-700">If an account exists for <strong>{email}</strong>, we've sent password reset instructions to it.</p>
            <Button variant="outline" className="mt-6 w-full" onClick={() => onSwitch('login')}>Back to sign in</Button>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-1.5"><Label>Email address</Label>
              <Input type="email" value={email} onChange={e => setEmail(e.target.value)} required /></div>
            <Button type="submit" className="w-full h-11 bg-teal-700 hover:bg-teal-800" disabled={loading}>
              {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Sending...</> : 'Send reset link'}
            </Button>
            <button type="button" onClick={() => onSwitch('login')} className="w-full text-sm text-teal-700 font-semibold hover:underline">Back to sign in</button>
          </form>
        )}
      </CardContent>
    </Card>
  )
}

// ---- Sidebar ---------------------------------------------------------------
const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'patients', label: 'Patients', icon: Users },
  { id: 'analysis', label: 'New Analysis', icon: ScanEye },
  { id: 'reports', label: 'Reports', icon: FileText },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'profile', label: 'My Profile', icon: User },
  { id: 'settings', label: 'Model / Admin', icon: Settings },
]

function Sidebar({ current, onNavigate, user }) {
  return (
    <aside className="w-64 shrink-0 bg-slate-900 text-slate-300 flex flex-col border-r border-slate-800">
      <div className="p-5 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-teal-600 text-white flex items-center justify-center"><Eye className="w-5 h-5" /></div>
          <div>
            <div className="text-white font-bold text-sm">RetinaGuard </div>
            <div className="text-[10px] text-teal-400 uppercase tracking-widest">Clinical DSS</div>
          </div>
        </div>
      </div>
      <nav className="flex-1 p-3 space-y-1">
        {NAV_ITEMS.map(item => {
          const Icon = item.icon
          const active = current === item.id
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                active ? 'bg-teal-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              {item.label}
              {active && <ChevronRight className="w-3.5 h-3.5 ml-auto" />}
            </button>
          )
        })}
      </nav>
      <div className="p-3 border-t border-slate-800">
        <div className="flex items-center gap-3 p-2 rounded-lg bg-slate-800/50">
          <Avatar className="w-8 h-8"><AvatarFallback className="bg-teal-600 text-white text-xs">{user?.name?.split(' ').map(s => s[0]).join('').slice(0,2)}</AvatarFallback></Avatar>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-semibold text-white truncate">{user?.name}</div>
            <div className="text-[10px] text-slate-500 truncate">{user?.role} · {user?.clinic}</div>
          </div>
        </div>
      </div>
    </aside>
  )
}

// ---- Top Bar ---------------------------------------------------------------
function TopBar({ title, subtitle, onLogout, onSearch }) {
  return (
    <header className="bg-white border-b border-slate-200 px-8 py-4 flex items-center justify-between">
      <div>
        <h1 className="text-xl font-bold text-slate-900">{title}</h1>
        {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
      </div>
      <div className="flex items-center gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Search patients, MRN..." className="pl-9 w-64" onChange={e => onSearch?.(e.target.value)} />
        </div>
        <Button variant="ghost" size="icon" onClick={onLogout} title="Sign out"><LogOut className="w-4 h-4" /></Button>
      </div>
    </header>
  )
}

// ---- Dashboard -------------------------------------------------------------
function DashboardView({ user, onNavigate }) {
  const [stats, setStats] = useState(null)
  useEffect(() => { api(`/dashboard/stats`).then(setStats).catch(e => toast.error(e.message)) }, [])
  if (!stats) return <div className="p-8"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>

  const pieData = SEVERITIES.map(s => ({ name: s, value: stats.severityDist[s] || 0, color: SEVERITY_COLORS[s].hex }))

  return (
    <div className="p-8 space-y-6 max-w-[1600px]">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Welcome back, {user.firstName || user.name?.split(' ')[0] || 'Doctor'}</h2>
          <p className="text-sm text-slate-500 mt-1">{user.role} · {user.clinic || 'RetinaGuard  Workspace'} · {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => onNavigate('patients')}><Plus className="w-4 h-4 mr-2" />Add Patient</Button>
          <Button className="bg-teal-700 hover:bg-teal-800" onClick={() => onNavigate('analysis')}><ScanEye className="w-4 h-4 mr-2" />New Analysis</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard icon={Users} label="Total Patients" value={stats.totalPatients} sub="Active in your caseload" tone="teal" />
        <StatCard icon={Activity} label="Scans This Month" value={stats.scansThisMonth} sub="+12% vs last month" tone="blue" />
        <StatCard icon={Clock} label="Pending Reviews" value={stats.pendingReviews} sub="Awaiting doctor verdict" tone="amber" />
        <StatCard icon={Zap} label="Avg Confidence" value={`${(stats.avgConfidence * 100).toFixed(1)}%`} sub="Model output calibrated" tone="emerald" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle className="text-base">Scans over the last 8 weeks</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={stats.scansOverTime}>
                <defs><linearGradient id="ct" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#14b8a6" stopOpacity={0.4}/><stop offset="95%" stopColor="#14b8a6" stopOpacity={0}/></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="week" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Area type="monotone" dataKey="count" stroke="#0d9488" fill="url(#ct)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">DR severity distribution</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={80} dataKey="value" paddingAngle={2}>
                  {pieData.map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-2 mt-2 text-xs">
              {pieData.map(d => <div key={d.name} className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: d.color }} /><span className="text-slate-600">{d.name}</span><span className="ml-auto font-semibold">{d.value}</span></div>)}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between"><CardTitle className="text-base">Recent scans</CardTitle><Button variant="ghost" size="sm" onClick={() => onNavigate('reports')}>View all</Button></CardHeader>
          <CardContent className="space-y-2">
            {stats.recentScans.map(s => (
              <div key={s.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:bg-slate-50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center overflow-hidden">
                    {s.imageUrl ? <img src={s.imageUrl} className="w-full h-full object-cover" alt="" /> : <Eye className="w-4 h-4 text-white" />}
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-slate-900">{s.patientName}</div>
                    <div className="text-xs text-slate-500">{s.eye} · {new Date(s.createdAt).toLocaleDateString()}</div>
                  </div>
                </div>
                <SeverityBadge severity={s.finalSeverity} />
              </div>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Recently added patients</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {stats.recentPatients.map(p => (
              <div key={p.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:bg-slate-50">
                <div className="flex items-center gap-3">
                  <Avatar className="w-9 h-9"><AvatarFallback className="bg-teal-100 text-teal-800 text-xs">{p.name.split(' ').map(x => x[0]).join('').slice(0,2)}</AvatarFallback></Avatar>
                  <div>
                    <div className="text-sm font-semibold text-slate-900">{p.name}</div>
                    <div className="text-xs text-slate-500">{p.mrn} · {p.age}y · {p.diabetesType}</div>
                  </div>
                </div>
                <span className="text-xs text-slate-400">{new Date(p.createdAt).toLocaleDateString()}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Alert className="border-amber-200 bg-amber-50">
        <ShieldCheck className="w-4 h-4 text-amber-700" />
        <AlertTitle className="text-amber-900">Clinical Disclaimer</AlertTitle>
        <AlertDescription className="text-amber-800">RetinaGuard  is an assistive decision-support tool. Final diagnostic determination must be confirmed by a licensed ophthalmologist. Not FDA-cleared as a stand-alone diagnostic device.</AlertDescription>
      </Alert>
    </div>
  )
}

// ---- Patients View ---------------------------------------------------------
function PatientsView({ user, onOpenPatient, onNavigate }) {
  const [patients, setPatients] = useState([])
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState('all')
  const [showAdd, setShowAdd] = useState(false)
  const [loading, setLoading] = useState(true)

  const load = () => { setLoading(true); api(`/patients?q=${encodeURIComponent(q)}`).then(setPatients).finally(() => setLoading(false)) }
  useEffect(() => { load() }, [q])

  const filtered = useMemo(() => {
    if (filter === 'all') return patients
    return patients.filter(p => p.latestSeverity === filter)
  }, [patients, filter])

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Patient records</h2>
          <p className="text-sm text-slate-500">Manage your caseload and view scan history.</p>
        </div>
        <Button className="bg-teal-700 hover:bg-teal-800" onClick={() => setShowAdd(true)}><Plus className="w-4 h-4 mr-2" />Add patient</Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="p-4 border-b border-slate-100 flex flex-wrap items-center gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input placeholder="Search by name or MRN..." className="pl-9" value={q} onChange={e => setQ(e.target.value)} />
            </div>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All severities</SelectItem>
                {SEVERITIES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          {loading ? (
            <div className="p-12 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 text-xs uppercase text-slate-500 tracking-wider">
                  <tr>
                    <th className="text-left px-4 py-3">Patient</th>
                    <th className="text-left px-4 py-3">MRN</th>
                    <th className="text-left px-4 py-3">Age / Sex</th>
                    <th className="text-left px-4 py-3">Diabetes</th>
                    <th className="text-left px-4 py-3">HbA1c</th>
                    <th className="text-left px-4 py-3">Latest DR</th>
                    <th className="text-left px-4 py-3">Scans</th>
                    <th className="text-left px-4 py-3">Last visit</th>
                    <th className="text-right px-4 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filtered.map(p => (
                    <tr key={p.id} className="hover:bg-slate-50 cursor-pointer" onClick={() => onOpenPatient(p.id)}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Avatar className="w-8 h-8"><AvatarFallback className="bg-teal-100 text-teal-800 text-[10px]">{p.name.split(' ').map(x => x[0]).join('').slice(0,2)}</AvatarFallback></Avatar>
                          <div className="font-medium text-slate-900">{p.name}</div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-slate-600 font-mono text-xs">{p.mrn}</td>
                      <td className="px-4 py-3 text-slate-600">{p.age}y · {p.gender?.[0]}</td>
                      <td className="px-4 py-3 text-slate-600">{p.diabetesType} · {p.diabetesDurationYears}y</td>
                      <td className="px-4 py-3"><span className={`font-mono ${p.hba1c > 8 ? 'text-red-600 font-semibold' : p.hba1c > 7 ? 'text-amber-600' : 'text-slate-600'}`}>{p.hba1c}%</span></td>
                      <td className="px-4 py-3">{p.latestSeverity ? <SeverityBadge severity={p.latestSeverity} /> : <span className="text-xs text-slate-400">No scans</span>}</td>
                      <td className="px-4 py-3 text-slate-600">{p.scanCount}</td>
                      <td className="px-4 py-3 text-xs text-slate-500">{p.lastVisit ? new Date(p.lastVisit).toLocaleDateString() : '—'}</td>
                      <td className="px-4 py-3 text-right"><Button variant="ghost" size="sm"><ChevronRight className="w-4 h-4" /></Button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filtered.length === 0 && <div className="p-12 text-center text-sm text-slate-500">No patients match your filters.</div>}
            </div>
          )}
        </CardContent>
      </Card>

      <AddPatientDialog open={showAdd} onOpenChange={setShowAdd} user={user} onCreated={() => { setShowAdd(false); load() }} />
    </div>
  )
}

function AddPatientDialog({ open, onOpenChange, user, onCreated }) {
  const [form, setForm] = useState({ name: '', age: '', gender: 'Female', email: '', phone: '', diabetesType: 'Type 2', diabetesDurationYears: '', hba1c: '', referringPhysician: '' })
  const [saving, setSaving] = useState(false)
  const upd = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const submit = async () => {
    if (!form.name || !form.age) return toast.error('Name and age are required')
    setSaving(true)
    try {
      await api('/patients', { method: 'POST', body: JSON.stringify({
        ...form, age: +form.age, diabetesDurationYears: +form.diabetesDurationYears || 0, hba1c: +form.hba1c || 0,
        doctorId: user.id, doctorName: user.name,
      })})
      toast.success('Patient added')
      setForm({ name: '', age: '', gender: 'Female', email: '', phone: '', diabetesType: 'Type 2', diabetesDurationYears: '', hba1c: '', referringPhysician: '' })
      onCreated()
    } catch (e) { toast.error(e.message) } finally { setSaving(false) }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader><DialogTitle>Register new patient</DialogTitle><DialogDescription>Enter patient demographics and diabetes history.</DialogDescription></DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-2">
          <div className="col-span-2 space-y-1.5"><Label>Full name *</Label><Input value={form.name} onChange={e => upd('name', e.target.value)} /></div>
          <div className="space-y-1.5"><Label>Age *</Label><Input type="number" value={form.age} onChange={e => upd('age', e.target.value)} /></div>
          <div className="space-y-1.5"><Label>Sex</Label>
            <Select value={form.gender} onValueChange={v => upd('gender', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Female">Female</SelectItem><SelectItem value="Male">Male</SelectItem><SelectItem value="Other">Other</SelectItem></SelectContent></Select>
          </div>
          <div className="space-y-1.5"><Label>Email</Label><Input value={form.email} onChange={e => upd('email', e.target.value)} /></div>
          <div className="space-y-1.5"><Label>Phone</Label><Input value={form.phone} onChange={e => upd('phone', e.target.value)} /></div>
          <div className="space-y-1.5"><Label>Diabetes type</Label>
            <Select value={form.diabetesType} onValueChange={v => upd('diabetesType', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Type 1">Type 1</SelectItem><SelectItem value="Type 2">Type 2</SelectItem><SelectItem value="Gestational">Gestational</SelectItem></SelectContent></Select>
          </div>
          <div className="space-y-1.5"><Label>Duration (years)</Label><Input type="number" value={form.diabetesDurationYears} onChange={e => upd('diabetesDurationYears', e.target.value)} /></div>
          <div className="space-y-1.5"><Label>Latest HbA1c (%)</Label><Input type="number" step="0.1" value={form.hba1c} onChange={e => upd('hba1c', e.target.value)} /></div>
          <div className="col-span-2 space-y-1.5"><Label>Referring physician</Label><Input value={form.referringPhysician} onChange={e => upd('referringPhysician', e.target.value)} /></div>
        </div>
        <DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button><Button className="bg-teal-700 hover:bg-teal-800" onClick={submit} disabled={saving}>{saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}Register patient</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ---- Patient Detail --------------------------------------------------------
function PatientDetailView({ patientId, user, onBack, onNewAnalysis, onViewScan }) {
  const [data, setData] = useState(null)
  useEffect(() => { api(`/patients/${patientId}`).then(setData).catch(e => toast.error(e.message)) }, [patientId])
  if (!data) return <div className="p-8"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
  const { patient: p, scans } = data
  const trend = [...scans].reverse().map(s => ({ date: new Date(s.createdAt).toLocaleDateString(), level: SEVERITIES.indexOf(s.finalSeverity), severity: s.finalSeverity }))

  return (
    <div className="p-8 space-y-6 max-w-[1500px]">
      <div className="flex items-center gap-2 text-sm text-slate-500"><Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="w-4 h-4 mr-1" />Patients</Button><span>/</span><span className="text-slate-700 font-medium">{p.name}</span></div>
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <Avatar className="w-16 h-16"><AvatarFallback className="bg-teal-100 text-teal-800 text-lg">{p.name.split(' ').map(x=>x[0]).join('').slice(0,2)}</AvatarFallback></Avatar>
          <div>
            <h2 className="text-2xl font-bold text-slate-900">{p.name}</h2>
            <p className="text-sm text-slate-500">{p.mrn} · {p.age}y · {p.gender} · {p.diabetesType} for {p.diabetesDurationYears}y · HbA1c {p.hba1c}%</p>
            <p className="text-xs text-slate-400 mt-1">Referred by {p.referringPhysician || '—'}</p>
          </div>
        </div>
        <Button className="bg-teal-700 hover:bg-teal-800" onClick={() => onNewAnalysis(p)}><ScanEye className="w-4 h-4 mr-2" />New scan</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle className="text-base">DR severity trend</CardTitle><CardDescription>Progression across visits (0=No DR, 4=Proliferative)</CardDescription></CardHeader>
          <CardContent>
            {trend.length ? (
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={trend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                  <YAxis domain={[0, 4]} ticks={[0,1,2,3,4]} tickFormatter={v => SEVERITIES[v]} tick={{ fontSize: 11 }} width={90} />
                  <Tooltip formatter={(v) => SEVERITIES[v]} />
                  <Line type="monotone" dataKey="level" stroke="#0d9488" strokeWidth={2.5} dot={{ r: 5, fill: '#0d9488' }} />
                </LineChart>
              </ResponsiveContainer>
            ) : <div className="py-12 text-center text-sm text-slate-400">No scan history yet.</div>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Clinical summary</CardTitle></CardHeader>
          <CardContent className="text-sm space-y-3">
            <div className="flex justify-between"><span className="text-slate-500">Total scans</span><span className="font-semibold">{scans.length}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Latest DR</span>{scans[0] ? <SeverityBadge severity={scans[0].finalSeverity} /> : '—'}</div>
            <div className="flex justify-between"><span className="text-slate-500">Last scan</span><span>{scans[0] ? new Date(scans[0].createdAt).toLocaleDateString() : '—'}</span></div>
            <Separator />
            <div className="flex justify-between"><span className="text-slate-500">Email</span><span className="text-xs">{p.email}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Phone</span><span className="text-xs">{p.phone}</span></div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Scan history ({scans.length})</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {scans.map(s => (
              <button key={s.id} onClick={() => onViewScan(s.id)} className="text-left rounded-lg border border-slate-200 hover:border-teal-500 hover:shadow-md transition-all overflow-hidden">
                <div className="aspect-video bg-slate-900 flex items-center justify-center overflow-hidden">
                  {s.imageUrl ? <img src={s.imageUrl} className="w-full h-full object-cover" alt="" /> : s.imageBase64 ? <img src={`data:${s.mimeType||'image/jpeg'};base64,${s.imageBase64}`} className="w-full h-full object-cover" alt="" /> : <Eye className="w-8 h-8 text-slate-600" />}
                </div>
                <div className="p-3 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500">{s.eye} · {new Date(s.createdAt).toLocaleDateString()}</span>
                    <SeverityBadge severity={s.finalSeverity} />
                  </div>
                  <div className="text-xs text-slate-600">Confidence {((s.result?.ensemble?.confidence||0)*100).toFixed(0)}%</div>
                </div>
              </button>
            ))}
            {scans.length === 0 && <div className="col-span-full text-center py-8 text-sm text-slate-400">No scans yet — start with a new analysis.</div>}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ---- New Analysis View -----------------------------------------------------
function NewAnalysisView({ user, preselectedPatient, onSaved, onBack }) {
  const [patients, setPatients] = useState([])
  const [patientId, setPatientId] = useState(preselectedPatient?.id || '')
  const [eye, setEye] = useState('OD')
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState('')
  const [analyzing, setAnalyzing] = useState(false)
  const [analysis, setAnalysis] = useState(null)
  const [heatmapOn, setHeatmapOn] = useState(true)
  const [viewMode, setViewMode] = useState('overlay')  // overlay | original | side
  const [notes, setNotes] = useState('')
  const [override, setOverride] = useState('')
  const [saving, setSaving] = useState(false)
  const [usedFallback, setUsedFallback] = useState(false)
  const fileRef = useRef()

  useEffect(() => { api('/patients').then(setPatients) }, [])
  useEffect(() => { if (preselectedPatient) setPatientId(preselectedPatient.id) }, [preselectedPatient])

  const onDrop = (e) => {
    e.preventDefault()
    const f = e.dataTransfer.files?.[0]; if (f) handleFile(f)
  }
  const handleFile = (f) => {
    setFile(f); setAnalysis(null)
    const reader = new FileReader()
    reader.onload = () => setPreview(reader.result)
    reader.readAsDataURL(f)
  }
  const fileToBase64 = (f) => new Promise((res, rej) => {
    const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.onerror = rej; r.readAsDataURL(f)
  })

  const runAnalysis = async () => {
    if (!file) return toast.error('Upload a fundus image first')
    if (!patientId) return toast.error('Select a patient')
    setAnalyzing(true); setAnalysis(null)
    try {
      const base64 = await fileToBase64(file)
      const { analysis, usedFallback } = await api('/scans/analyze', { method: 'POST', body: JSON.stringify({ imageBase64: base64, mimeType: file.type }) })
      setAnalysis(analysis); setUsedFallback(usedFallback)
      setOverride(analysis.ensemble.severity)
      if (usedFallback) toast.warning('Using local model fallback. Real ensemble inference retried below.')
      else toast.success(`Analysis complete: ${analysis.ensemble.severity}`)
    } catch (e) { toast.error(e.message) } finally { setAnalyzing(false) }
  }

  const save = async (verdict) => {
    if (!analysis) return
    setSaving(true)
    try {
      const base64 = await fileToBase64(file)
      const patient = patients.find(p => p.id === patientId)
      await api('/scans', { method: 'POST', body: JSON.stringify({
        patientId, patientName: patient?.name, doctorId: user.id, doctorName: user.name, eye,
        imageBase64: base64, mimeType: file.type,
        result: analysis, doctorNotes: notes, doctorVerdict: verdict,
        finalSeverity: override || analysis.ensemble.severity,
      })})
      toast.success('Scan saved to patient record')
      onSaved(patientId)
    } catch (e) { toast.error(e.message) } finally { setSaving(false) }
  }

  const probData = analysis ? Object.entries(analysis.ensemble.probabilities).map(([k, v]) => ({ name: k, prob: +(v*100).toFixed(1), color: SEVERITY_COLORS[k].hex })) : []

  return (
    <div className="p-8 space-y-6 max-w-[1600px]">
      <div className="flex items-center gap-2 text-sm text-slate-500">
        {onBack && <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="w-4 h-4 mr-1" />Back</Button>}
        <h2 className="text-2xl font-bold text-slate-900 ml-2">New retinal analysis</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Upload column */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base">1 · Patient & eye</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5"><Label>Patient</Label>
                <Select value={patientId} onValueChange={setPatientId}>
                  <SelectTrigger><SelectValue placeholder="Select patient" /></SelectTrigger>
                  <SelectContent>{patients.map(p => <SelectItem key={p.id} value={p.id}>{p.name} · {p.mrn}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Eye</Label>
                <Select value={eye} onValueChange={setEye}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="OD">OD (Right)</SelectItem><SelectItem value="OS">OS (Left)</SelectItem></SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">2 · Fundus image</CardTitle><CardDescription>JPG / PNG · up to 12MB</CardDescription></CardHeader>
            <CardContent>
              <div
                onDragOver={e => e.preventDefault()}
                onDrop={onDrop}
                onClick={() => fileRef.current?.click()}
                className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center cursor-pointer hover:border-teal-500 hover:bg-teal-50/30 transition-colors"
              >
                {preview ? (
                  <img src={preview} className="max-h-48 mx-auto rounded" alt="Preview" />
                ) : (
                  <div className="py-6">
                    <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm font-medium text-slate-700">Drop fundus image or click to upload</p>
                    <p className="text-xs text-slate-500 mt-1">JPEG / PNG · single or drag-drop</p>
                  </div>
                )}
                <input ref={fileRef} type="file" accept="image/*" hidden onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">3 · Run hybrid ensemble</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              <div className="text-xs text-slate-500 space-y-1 mb-3">
                <div className="flex items-center gap-2"><Layers className="w-3 h-3" /> EfficientNet-B4 · ResNet-50 · DenseNet-121</div>
                <div className="flex items-center gap-2"><Brain className="w-3 h-3" /> Weighted soft-voting + temperature scaling</div>
              </div>
              <Button onClick={runAnalysis} disabled={!file || !patientId || analyzing} className="w-full bg-teal-700 hover:bg-teal-800">
                {analyzing ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Running inference...</> : <><Zap className="w-4 h-4 mr-2" />Run analysis</>}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Results column */}
        <div className="lg:col-span-3 space-y-4">
          {!analysis && !analyzing && (
            <Card className="border-dashed border-2 border-slate-200"><CardContent className="p-16 text-center text-slate-400">
              <ScanEye className="w-16 h-16 mx-auto mb-4 opacity-30" />
              <p className="font-medium">Results will appear here after analysis.</p>
              <p className="text-xs mt-1">Ensemble severity, per-class probabilities, Grad-CAM overlay, and clinical recommendation.</p>
            </CardContent></Card>
          )}
          {analyzing && (
            <Card><CardContent className="p-16 text-center">
              <div className="relative inline-block"><div className="w-20 h-20 rounded-full border-4 border-teal-100 border-t-teal-600 animate-spin" /><Eye className="w-8 h-8 text-teal-600 absolute inset-0 m-auto" /></div>
              <p className="mt-4 font-semibold text-slate-700">Running hybrid CNN ensemble</p>
              <p className="text-xs text-slate-500 mt-1">Analyzing fundus image · Grad-CAM extraction · Fusion...</p>
            </CardContent></Card>
          )}
          {analysis && <ResultsPanel analysis={analysis} preview={preview} viewMode={viewMode} setViewMode={setViewMode} heatmapOn={heatmapOn} setHeatmapOn={setHeatmapOn} probData={probData} notes={notes} setNotes={setNotes} override={override} setOverride={setOverride} onSave={save} saving={saving} usedFallback={usedFallback} />}
        </div>
      </div>
    </div>
  )
}

function ResultsPanel({ analysis, preview, viewMode, setViewMode, heatmapOn, setHeatmapOn, probData, notes, setNotes, override, setOverride, onSave, saving, usedFallback }) {
  const e = analysis.ensemble
  const c = SEVERITY_COLORS[e.severity]
  const urgencyColor = { routine: 'bg-emerald-100 text-emerald-800', 'non-urgent': 'bg-yellow-100 text-yellow-800', urgent: 'bg-orange-100 text-orange-800', immediate: 'bg-red-100 text-red-800' }
  return (
    <div className="space-y-4">
      {usedFallback && <Alert className="border-amber-300 bg-amber-50"><Info className="w-4 h-4 text-amber-700" /><AlertTitle className="text-amber-900">Fallback model in use</AlertTitle><AlertDescription className="text-amber-800 text-xs">Vision API unavailable — displaying deterministic simulated ensemble output. Configure EMERGENT_LLM_KEY for live inference.</AlertDescription></Alert>}

      <Card className={`border-l-4 ${c.border}`}>
        <CardContent className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-xs text-slate-500 uppercase tracking-wide font-semibold mb-1">Ensemble prediction</div>
              <div className="text-3xl font-bold text-slate-900">{e.severity}</div>
              <div className="text-sm text-slate-600 mt-1">Confidence <span className="font-semibold">{(e.confidence*100).toFixed(1)}%</span> · Agreement <span className="font-semibold">{(e.agreement*100).toFixed(0)}%</span></div>
            </div>
            <div className="flex flex-col items-end gap-2">
              <SeverityBadge severity={e.severity} />
              <span className={`text-xs px-2 py-1 rounded-full font-semibold ${urgencyColor[analysis.referral_urgency] || 'bg-slate-100'}`}>Referral: {analysis.referral_urgency}</span>
              <span className="text-xs text-slate-500">Follow-up in {analysis.follow_up_months} months</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Retinal image · Grad-CAM overlay</CardTitle>
            <Tabs value={viewMode} onValueChange={setViewMode}><TabsList className="h-8"><TabsTrigger value="original" className="text-xs">Original</TabsTrigger><TabsTrigger value="overlay" className="text-xs">Overlay</TabsTrigger><TabsTrigger value="side" className="text-xs">Side-by-side</TabsTrigger></TabsList></Tabs>
          </div>
        </CardHeader>
        <CardContent>
          <div className={viewMode === 'side' ? 'grid grid-cols-2 gap-3' : ''}>
            {(viewMode === 'original' || viewMode === 'side') && (
              <div className="relative rounded-lg overflow-hidden bg-slate-900"><img src={preview} className="w-full aspect-square object-contain" alt="Fundus" /></div>
            )}
            {(viewMode === 'overlay' || viewMode === 'side') && (
              <div className="relative rounded-lg overflow-hidden bg-slate-900">
                <img src={preview} className="w-full aspect-square object-contain" alt="Fundus" />
                {heatmapOn && analysis.lesions?.map((l, i) => {
                  const [y1,x1,y2,x2] = l.box_2d
                  const color = LESION_COLORS[l.type] || '#ef4444'
                  return (
                    <div key={i} title={`${l.type}: ${l.description}`} className="absolute rounded ring-2 backdrop-blur-[1px]"
                      style={{ top:`${y1/10}%`, left:`${x1/10}%`, width:`${(x2-x1)/10}%`, height:`${(y2-y1)/10}%`, backgroundColor: color+'44', borderColor: color, boxShadow: `0 0 20px ${color}80` }}>
                      <div className="absolute -top-5 left-0 text-[10px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap" style={{ backgroundColor: color, color: 'white' }}>{l.type}</div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
          <div className="flex items-center justify-between mt-3">
            <label className="flex items-center gap-2 text-xs text-slate-600"><input type="checkbox" checked={heatmapOn} onChange={e => setHeatmapOn(e.target.checked)} />Show lesion heatmap</label>
            <div className="flex gap-2 text-[10px]">
              {[...new Set(analysis.lesions?.map(l => l.type) || [])].map(t => <span key={t} className="px-1.5 py-0.5 rounded font-medium" style={{ backgroundColor: (LESION_COLORS[t]||'#ef4444')+'20', color: LESION_COLORS[t]||'#ef4444' }}>{t}</span>)}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">Per-class probability distribution</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={probData} layout="vertical" margin={{ left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
              <XAxis type="number" domain={[0,100]} tick={{ fontSize: 11 }} />
              <YAxis dataKey="name" type="category" tick={{ fontSize: 11 }} width={80} />
              <Tooltip formatter={(v) => `${v}%`} />
              <Bar dataKey="prob" radius={[0,4,4,0]}>{probData.map((d,i) => <Cell key={i} fill={d.color} />)}</Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">Per-backbone predictions (transparency)</CardTitle><CardDescription>Individual CNN outputs before ensemble fusion</CardDescription></CardHeader>
        <CardContent><div className="grid grid-cols-3 gap-3">
          {analysis.backbones?.map(b => (
            <div key={b.name} className="border border-slate-200 rounded-lg p-3">
              <div className="text-xs font-mono text-slate-500 mb-1">{b.name}</div>
              <SeverityBadge severity={b.severity} />
              <div className="text-xs text-slate-500 mt-2">Conf {(b.confidence*100).toFixed(0)}%</div>
              <div className="mt-2 space-y-0.5">
                {Object.entries(b.probabilities).map(([k,v]) => (
                  <div key={k} className="flex items-center gap-1.5"><span className="text-[10px] text-slate-500 w-20 truncate">{k}</span><div className="flex-1 h-1.5 rounded-full bg-slate-100 overflow-hidden"><div className="h-full rounded-full" style={{ width: `${v*100}%`, backgroundColor: SEVERITY_COLORS[k].hex }} /></div></div>
                ))}
              </div>
            </div>
          ))}
        </div></CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">AI-generated clinical note</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="p-4 bg-slate-50 rounded-lg text-sm text-slate-700 leading-relaxed border-l-2 border-teal-600">{analysis.clinical_note}</div>
          {analysis.lesions?.length > 0 && (
            <div><div className="text-xs font-semibold text-slate-500 uppercase mb-1.5">Detected lesions</div><ul className="text-xs text-slate-600 space-y-1">{analysis.lesions.map((l,i) => <li key={i} className="flex gap-2"><span className="w-2 h-2 rounded-full mt-1" style={{background: LESION_COLORS[l.type]||'#ef4444'}} /><span><span className="font-semibold capitalize">{l.type.replace('_',' ')}:</span> {l.description} <span className="text-slate-400">({(l.confidence*100).toFixed(0)}% conf)</span></span></li>)}</ul></div>
          )}
          {analysis.limitations?.length > 0 && <div className="text-[11px] text-slate-500 italic">Limitations: {analysis.limitations.join(' · ')}</div>}
        </CardContent>
      </Card>

      <Card className="border-teal-200 bg-teal-50/40">
        <CardHeader className="pb-3"><CardTitle className="text-base">4 · Doctor review (human-in-the-loop)</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-1.5">
            <Label>Final severity (override if needed)</Label>
            <Select value={override} onValueChange={setOverride}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{SEVERITIES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select>
          </div>
          <div className="space-y-1.5"><Label>Clinical notes</Label><Textarea rows={3} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Additional observations, treatment plan, patient counseling..." /></div>
          <div className="flex gap-2 pt-2">
            <Button className="flex-1 bg-teal-700 hover:bg-teal-800" onClick={() => onSave('accepted')} disabled={saving}>{saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}<CheckCircle2 className="w-4 h-4 mr-2" />Accept & save</Button>
            <Button variant="outline" className="flex-1" onClick={() => onSave('overridden')} disabled={saving}><Edit className="w-4 h-4 mr-2" />Override & save</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ---- Scan Detail (with PDF report) -----------------------------------------
function ScanDetailView({ scanId, user, onBack }) {
  const [scan, setScan] = useState(null)
  useEffect(() => { api(`/scans/${scanId}`).then(setScan).catch(e => toast.error(e.message)) }, [scanId])
  if (!scan) return <div className="p-8"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
  const imgSrc = scan.imageBase64 ? `data:${scan.mimeType||'image/jpeg'};base64,${scan.imageBase64}` : scan.imageUrl
  return (
    <div className="p-8 space-y-6 max-w-[1400px]">
      <div className="flex items-center justify-between print:hidden">
        <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="w-4 h-4 mr-1" />Back</Button>
        <Button onClick={() => window.print()} className="bg-teal-700 hover:bg-teal-800"><Printer className="w-4 h-4 mr-2" />Print / Save PDF</Button>
      </div>
      <div id="print-area" className="bg-white p-8 rounded-xl border border-slate-200 space-y-6">
        <div className="flex items-start justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-teal-700 text-white flex items-center justify-center"><Eye className="w-6 h-6" /></div>
            <div><div className="text-lg font-bold">RetinaGuard</div><div className="text-xs text-slate-500">Diabetic Retinopathy Screening Report</div></div>
          </div>
          <div className="text-right text-xs text-slate-500"><div>Report ID: <span className="font-mono">{scan.id.slice(0,8)}</span></div><div>Generated: {new Date().toLocaleString()}</div><div>Model: {scan.modelVersion}</div></div>
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div><div className="text-xs uppercase text-slate-500 font-semibold mb-1">Patient</div><div className="font-semibold text-slate-900">{scan.patientName}</div><div className="text-xs text-slate-600">Scan of {scan.eye === 'OD' ? 'Right Eye (OD)' : 'Left Eye (OS)'}</div><div className="text-xs text-slate-600">Captured: {new Date(scan.createdAt).toLocaleString()}</div></div>
          <div className="text-right"><div className="text-xs uppercase text-slate-500 font-semibold mb-1">Interpreting clinician</div><div className="font-semibold text-slate-900">{scan.doctorName}</div><div className="text-xs text-slate-600">Verdict: <span className="capitalize">{scan.doctorVerdict}</span></div></div>
        </div>

        <div className="grid grid-cols-2 gap-6">
          <div className="rounded-lg overflow-hidden bg-slate-900 relative aspect-square">
            {imgSrc && <img src={imgSrc} className="w-full h-full object-contain" alt="Fundus" />}
            {scan.result?.lesions?.map((l,i) => { const [y1,x1,y2,x2] = l.box_2d; const c = LESION_COLORS[l.type]||'#ef4444'; return (
              <div key={i} className="absolute ring-2 rounded" style={{ top:`${y1/10}%`,left:`${x1/10}%`,width:`${(x2-x1)/10}%`,height:`${(y2-y1)/10}%`, backgroundColor:c+'33', borderColor:c }} />
            )})}
          </div>
          <div className="space-y-4">
            <div><div className="text-xs uppercase text-slate-500 font-semibold mb-1">Final diagnosis</div><div className="flex items-center gap-3"><span className="text-2xl font-bold">{scan.finalSeverity}</span><SeverityBadge severity={scan.finalSeverity} /></div></div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><div className="text-xs text-slate-500">Confidence</div><div className="font-semibold">{((scan.result?.ensemble?.confidence||0)*100).toFixed(1)}%</div></div>
              <div><div className="text-xs text-slate-500">Ensemble agreement</div><div className="font-semibold">{((scan.result?.ensemble?.agreement||1)*100).toFixed(0)}%</div></div>
              <div><div className="text-xs text-slate-500">Referral urgency</div><div className="font-semibold capitalize">{scan.result?.referral_urgency}</div></div>
              <div><div className="text-xs text-slate-500">Follow-up</div><div className="font-semibold">{scan.result?.follow_up_months} months</div></div>
            </div>
            <div><div className="text-xs uppercase text-slate-500 font-semibold mb-1">Clinical impression</div><p className="text-sm text-slate-700 leading-relaxed">{scan.result?.clinical_note}</p></div>
            {scan.doctorNotes && <div><div className="text-xs uppercase text-slate-500 font-semibold mb-1">Doctor's notes</div><p className="text-sm text-slate-700">{scan.doctorNotes}</p></div>}
          </div>
        </div>

        <div>
          <div className="text-xs uppercase text-slate-500 font-semibold mb-2">Per-class probabilities</div>
          <div className="space-y-1.5">{Object.entries(scan.result?.ensemble?.probabilities || {}).map(([k,v]) => (
            <div key={k} className="flex items-center gap-2 text-xs"><span className="w-24">{k}</span><div className="flex-1 h-2 rounded-full bg-slate-100 overflow-hidden"><div className="h-full" style={{ width:`${v*100}%`, backgroundColor: SEVERITY_COLORS[k].hex }} /></div><span className="w-12 text-right font-mono">{(v*100).toFixed(1)}%</span></div>
          ))}</div>
        </div>

        <div>
          <div className="text-xs uppercase text-slate-500 font-semibold mb-2">Backbone predictions</div>
          <div className="grid grid-cols-3 gap-2 text-xs">{scan.result?.backbones?.map(b => (
            <div key={b.name} className="border border-slate-200 rounded p-2"><div className="font-mono text-[10px] text-slate-500">{b.name}</div><div className="font-semibold mt-1">{b.severity}</div><div className="text-slate-500">{(b.confidence*100).toFixed(0)}% conf</div></div>
          ))}</div>
        </div>

        <div className="pt-4 border-t border-slate-200 text-[10px] text-slate-500 leading-relaxed">
          <p><strong>Disclaimer:</strong> This report is generated by RetinaGuard, an assistive decision-support tool. Grading is based on a hybrid CNN ensemble (EfficientNet-B4, ResNet-50, DenseNet-121) with weighted soft-voting fusion. Final diagnostic determination must be confirmed by a licensed ophthalmologist. Not FDA-cleared as a standalone diagnostic device.</p>
          <div className="mt-6 grid grid-cols-2 gap-8"><div className="border-t border-slate-400 pt-1"><div className="text-xs">{scan.doctorName}, {user?.specialization || 'Physician'}</div><div className="text-[10px]">Interpreting clinician signature</div></div><div className="border-t border-slate-400 pt-1"><div className="text-xs">{new Date().toLocaleDateString()}</div><div className="text-[10px]">Date</div></div></div>
        </div>
      </div>
    </div>
  )
}

// ---- Reports View ----------------------------------------------------------
function ReportsView({ onViewScan }) {
  const [scans, setScans] = useState([])
  useEffect(() => { api('/scans').then(setScans) }, [])
  return (
    <div className="p-8 space-y-6">
      <div><h2 className="text-2xl font-bold text-slate-900">Reports</h2><p className="text-sm text-slate-500">All scan reports with PDF export.</p></div>
      <Card><CardContent className="p-0"><div className="overflow-x-auto"><table className="w-full text-sm">
        <thead className="bg-slate-50 text-xs uppercase text-slate-500"><tr><th className="text-left px-4 py-3">Report ID</th><th className="text-left px-4 py-3">Patient</th><th className="text-left px-4 py-3">Eye</th><th className="text-left px-4 py-3">Severity</th><th className="text-left px-4 py-3">Confidence</th><th className="text-left px-4 py-3">Verdict</th><th className="text-left px-4 py-3">Date</th><th className="text-right px-4 py-3">Action</th></tr></thead>
        <tbody className="divide-y divide-slate-100">{scans.map(s => (
          <tr key={s.id} className="hover:bg-slate-50">
            <td className="px-4 py-3 font-mono text-xs">{s.id.slice(0,8)}</td>
            <td className="px-4 py-3 font-medium">{s.patientName}</td>
            <td className="px-4 py-3">{s.eye}</td>
            <td className="px-4 py-3"><SeverityBadge severity={s.finalSeverity} /></td>
            <td className="px-4 py-3 text-slate-600">{((s.result?.ensemble?.confidence||0)*100).toFixed(1)}%</td>
            <td className="px-4 py-3 capitalize text-slate-600">{s.doctorVerdict}</td>
            <td className="px-4 py-3 text-xs text-slate-500">{new Date(s.createdAt).toLocaleDateString()}</td>
            <td className="px-4 py-3 text-right"><Button size="sm" variant="ghost" onClick={() => onViewScan(s.id)}><FileText className="w-4 h-4 mr-1" />View</Button></td>
          </tr>
        ))}</tbody></table>
        {scans.length === 0 && <div className="p-12 text-center text-sm text-slate-400">No reports yet.</div>}
      </div></CardContent></Card>
    </div>
  )
}

// ---- Analytics View --------------------------------------------------------
function AnalyticsView() {
  const [data, setData] = useState(null)
  useEffect(() => { api('/analytics').then(setData) }, [])
  if (!data) return <div className="p-8"><Loader2 className="w-6 h-6 animate-spin text-teal-600" /></div>
  const sevData = SEVERITIES.map(s => ({ name: s, count: data.severityDist[s] || 0, color: SEVERITY_COLORS[s].hex }))
  const ageData = Object.entries(data.ageGroups).map(([k,v]) => ({ name: k, count: v }))
  return (
    <div className="p-8 space-y-6">
      <div><h2 className="text-2xl font-bold text-slate-900">Analytics</h2><p className="text-sm text-slate-500">Clinical population insights and model performance.</p></div>
      <div className="grid grid-cols-4 gap-4">
        <StatCard icon={Users} label="Total Patients" value={data.totalPatients} tone="teal" />
        <StatCard icon={Activity} label="Total Scans" value={data.totalScans} tone="blue" />
        <StatCard icon={Zap} label="Avg Confidence" value={`${(data.avgConfidence*100).toFixed(1)}%`} tone="emerald" />
        <StatCard icon={Layers} label="Backbone Agreement" value={`${(data.backboneAgreement*100).toFixed(1)}%`} tone="amber" />
      </div>
      <div className="grid grid-cols-2 gap-6">
        <Card><CardHeader><CardTitle className="text-base">DR severity distribution</CardTitle></CardHeader><CardContent>
          <ResponsiveContainer width="100%" height={280}><BarChart data={sevData}><CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" /><XAxis dataKey="name" tick={{fontSize:11}} /><YAxis tick={{fontSize:11}} /><Tooltip /><Bar dataKey="count" radius={[6,6,0,0]}>{sevData.map((d,i)=><Cell key={i} fill={d.color} />)}</Bar></BarChart></ResponsiveContainer>
        </CardContent></Card>
        <Card><CardHeader><CardTitle className="text-base">Patient age groups</CardTitle></CardHeader><CardContent>
          <ResponsiveContainer width="100%" height={280}><BarChart data={ageData}><CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" /><XAxis dataKey="name" tick={{fontSize:11}} /><YAxis tick={{fontSize:11}} /><Tooltip /><Bar dataKey="count" fill="#0d9488" radius={[6,6,0,0]} /></BarChart></ResponsiveContainer>
        </CardContent></Card>
      </div>
      <Card><CardHeader><CardTitle className="text-base">Scans by month</CardTitle></CardHeader><CardContent>
        <ResponsiveContainer width="100%" height={240}><LineChart data={data.scansByMonth}><CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" /><XAxis dataKey="month" tick={{fontSize:11}} /><YAxis tick={{fontSize:11}} /><Tooltip /><Line dataKey="count" stroke="#0d9488" strokeWidth={2.5} dot={{r:4}} /></LineChart></ResponsiveContainer>
      </CardContent></Card>
    </div>
  )
}

// ---- Settings / Admin View -------------------------------------------------
function SettingsView() {
  const [versions, setVersions] = useState([])
  const [logs, setLogs] = useState([])
  useEffect(() => { api('/model/info').then(setVersions); api('/audit').then(setLogs) }, [])
  const active = versions.find(v => v.active)
  return (
    <div className="p-8 space-y-6">
      <div><h2 className="text-2xl font-bold text-slate-900">Model / Admin</h2><p className="text-sm text-slate-500">Active model version, evaluation metrics, and audit trail.</p></div>
      {active && (
        <Card><CardHeader><div className="flex items-center justify-between"><div><CardTitle className="text-base">Active model · <span className="font-mono">{active.version}</span></CardTitle><CardDescription>Released {new Date(active.releasedAt).toLocaleDateString()}</CardDescription></div><Badge className="bg-emerald-100 text-emerald-800 border-emerald-300">Active</Badge></div></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-5 gap-4">
            <div className="p-3 bg-slate-50 rounded-lg"><div className="text-xs text-slate-500">Accuracy</div><div className="text-xl font-bold text-teal-700">{(active.metrics.accuracy*100).toFixed(2)}%</div></div>
            <div className="p-3 bg-slate-50 rounded-lg"><div className="text-xs text-slate-500">Sensitivity</div><div className="text-xl font-bold">{(active.metrics.sensitivity*100).toFixed(2)}%</div></div>
            <div className="p-3 bg-slate-50 rounded-lg"><div className="text-xs text-slate-500">Specificity</div><div className="text-xl font-bold">{(active.metrics.specificity*100).toFixed(2)}%</div></div>
            <div className="p-3 bg-slate-50 rounded-lg"><div className="text-xs text-slate-500">AUC</div><div className="text-xl font-bold">{active.metrics.auc.toFixed(3)}</div></div>
            <div className="p-3 bg-slate-50 rounded-lg"><div className="text-xs text-slate-500">Quad. Kappa</div><div className="text-xl font-bold">{active.metrics.quadraticKappa.toFixed(3)}</div></div>
          </div>
          <div><div className="text-xs font-semibold uppercase text-slate-500 mb-2">Architecture</div><div className="flex gap-2 flex-wrap">{active.backbones.map(b => <Badge key={b} variant="outline">{b}</Badge>)}<Badge variant="outline" className="bg-teal-50">Fusion: {active.fusion}</Badge></div></div>
          <div><div className="text-xs font-semibold uppercase text-slate-500 mb-2">Training data</div><div className="text-sm text-slate-700">{active.trainingDataset}</div></div>
          <div>
            <div className="text-xs font-semibold uppercase text-slate-500 mb-2">Confusion matrix (test set)</div>
            <div className="inline-block border border-slate-200 rounded-lg overflow-hidden text-xs">
              <table><thead><tr className="bg-slate-100"><th className="px-2 py-1"></th>{SEVERITIES.map(s => <th key={s} className="px-3 py-1 text-slate-600">{s.slice(0,3)}</th>)}</tr></thead>
              <tbody>{active.confusionMatrix.map((row,i) => <tr key={i}><td className="px-3 py-1 bg-slate-50 font-semibold">{SEVERITIES[i].slice(0,3)}</td>{row.map((v,j) => { const max = Math.max(...row); const intensity = v/max; return <td key={j} className="px-3 py-1 text-center font-mono" style={{background: i===j ? `rgba(16,185,129,${intensity*0.5})` : `rgba(239,68,68,${intensity*0.3})`}}>{v}</td>})}</tr>)}</tbody></table>
            </div>
          </div>
        </CardContent></Card>
      )}
      <Card><CardHeader><CardTitle className="text-base">Version history</CardTitle></CardHeader><CardContent>
        <div className="space-y-2">{versions.map(v => (
          <div key={v.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-100"><div><div className="font-mono text-sm font-semibold">{v.version}</div><div className="text-xs text-slate-500">Released {new Date(v.releasedAt).toLocaleDateString()} · Acc {(v.metrics.accuracy*100).toFixed(1)}%</div></div>{v.active ? <Badge className="bg-emerald-100 text-emerald-800">Active</Badge> : <Button size="sm" variant="outline">Rollback</Button>}</div>
        ))}</div>
      </CardContent></Card>
      <Card><CardHeader><CardTitle className="text-base">Audit log</CardTitle><CardDescription>Latest patient record access and modifications</CardDescription></CardHeader><CardContent>
        <div className="space-y-1.5 text-xs">{logs.slice(0, 15).map(l => (
          <div key={l.id} className="flex items-center gap-2 py-1.5 border-b border-slate-50"><Clock className="w-3 h-3 text-slate-400" /><span className="text-slate-500 w-40">{new Date(l.timestamp).toLocaleString()}</span><span className="font-semibold text-slate-700">{l.userName}</span><span className="text-slate-500">{l.action}</span><span className="font-mono text-slate-400">{l.target?.slice(0,12)}</span></div>
        ))}</div>
      </CardContent></Card>
    </div>
  )
}

// ---- Profile View ----------------------------------------------------------
function ProfileView({ user, onUserUpdate }) {
  const [form, setForm] = useState({
    firstName: user.firstName || '', lastName: user.lastName || '',
    phone: user.phone || '', clinic: user.clinic || '',
    specialization: user.specialization || '', license: user.license || '',
  })
  const [saving, setSaving] = useState(false)
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const save = async (e) => {
    e.preventDefault(); setSaving(true)
    try {
      const res = await fetch('/api/users/profile', {
        method: 'PUT', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Update failed')
      onUserUpdate(data.user)
      toast.success('Profile updated')
    } catch (err) { toast.error(err.message) } finally { setSaving(false) }
  }
  return (
    <div className="p-8 space-y-6 max-w-3xl">
      <div><h2 className="text-2xl font-bold text-slate-900">My Profile</h2><p className="text-sm text-slate-500">Manage your personal information.</p></div>
      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16"><AvatarFallback className="bg-teal-100 text-teal-800 text-lg">{(user.firstName?.[0] || '') + (user.lastName?.[0] || '')}</AvatarFallback></Avatar>
            <div>
              <CardTitle className="text-xl">{user.firstName} {user.lastName}</CardTitle>
              <CardDescription className="flex items-center gap-3 mt-1">
                <span className="flex items-center gap-1"><Mail className="w-3 h-3" />{user.email}</span>
                <span>·</span><Badge variant="outline">{user.role}</Badge>
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={save} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5"><Label>First name</Label><Input value={form.firstName} onChange={e => set('firstName', e.target.value)} /></div>
              <div className="space-y-1.5"><Label>Last name</Label><Input value={form.lastName} onChange={e => set('lastName', e.target.value)} /></div>
              <div className="space-y-1.5"><Label>Email</Label><Input value={user.email} disabled className="bg-slate-50" /></div>
              <div className="space-y-1.5"><Label>Phone</Label><Input value={form.phone} onChange={e => set('phone', e.target.value)} /></div>
              <div className="space-y-1.5"><Label>Role</Label><Input value={user.role} disabled className="bg-slate-50" /></div>
              <div className="space-y-1.5"><Label>Clinic / Hospital</Label><Input value={form.clinic} onChange={e => set('clinic', e.target.value)} /></div>
              <div className="space-y-1.5"><Label>Specialization</Label><Input value={form.specialization} onChange={e => set('specialization', e.target.value)} /></div>
              <div className="space-y-1.5"><Label>Medical license / ID</Label><Input value={form.license} onChange={e => set('license', e.target.value)} /></div>
              <div className="space-y-1.5 col-span-2"><Label>Account created</Label><Input value={new Date(user.createdAt).toLocaleString()} disabled className="bg-slate-50" /></div>
            </div>
            <Button type="submit" disabled={saving} className="bg-teal-700 hover:bg-teal-800">
              {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</> : 'Save changes'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

// ---- Main App --------------------------------------------------------------
function App() {
  const [user, setUser] = useState(null)
  const [booting, setBooting] = useState(true)
  const [view, setView] = useState('dashboard')
  const [selectedPatient, setSelectedPatient] = useState(null)
  const [selectedScan, setSelectedScan] = useState(null)
  const [analysisPatient, setAnalysisPatient] = useState(null)

  useEffect(() => {
    // Auth state comes ONLY from the server (HttpOnly cookie via /api/auth/me).
    // We NEVER trust localStorage as an auth source.
    (async () => {
      try {
        const res = await fetch('/api/auth/me', { credentials: 'include' })
        if (res.ok) {
          const data = await res.json()
          if (data.user) setUser(data.user)
        }
      } catch (_) {}
      setBooting(false)
    })()
  }, [])

  if (booting) return <div className="min-h-screen flex items-center justify-center bg-slate-50"><Loader2 className="w-8 h-8 animate-spin text-teal-600" /></div>
  if (!user) return <AuthView onLogin={setUser} />

  const logout = async () => {
    try { await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' }) } catch (_) {}
    setUser(null)
    setView('dashboard')
  }
  const navigate = (v) => { setView(v); setSelectedPatient(null); setSelectedScan(null); setAnalysisPatient(null) }

  const titles = {
    dashboard: ['Dashboard', 'Clinical overview and quick actions'],
    patients: ['Patients', 'Manage your patient records'],
    analysis: ['New Analysis', 'Upload a fundus image and run the ensemble'],
    reports: ['Reports', 'Scan reports and PDF export'],
    analytics: ['Analytics', 'Population insights and model KPIs'],
    profile: ['My Profile', 'Personal information and preferences'],
    settings: ['Model & Admin', 'Model versions, metrics, and audit'],
  }
  const [title, subtitle] = selectedPatient ? ['Patient profile', 'Full history and trend'] : selectedScan ? ['Scan report', 'PDF-ready detail view'] : titles[view]

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <div className="print:hidden"><Sidebar current={view} onNavigate={navigate} user={user} /></div>
      <div className="flex-1 flex flex-col min-w-0">
        <div className="print:hidden"><TopBar title={title} subtitle={subtitle} onLogout={logout} /></div>
        <main className="flex-1 overflow-auto">
          {selectedScan ? (
            <ScanDetailView scanId={selectedScan} user={user} onBack={() => setSelectedScan(null)} />
          ) : selectedPatient ? (
            <PatientDetailView patientId={selectedPatient} user={user} onBack={() => setSelectedPatient(null)}
              onNewAnalysis={(p) => { setAnalysisPatient(p); setSelectedPatient(null); setView('analysis') }}
              onViewScan={(id) => setSelectedScan(id)} />
          ) : view === 'dashboard' ? (
            <DashboardView user={user} onNavigate={navigate} />
          ) : view === 'patients' ? (
            <PatientsView user={user} onOpenPatient={(id) => setSelectedPatient(id)} onNavigate={navigate} />
          ) : view === 'analysis' ? (
            <NewAnalysisView user={user} preselectedPatient={analysisPatient} onSaved={(pid) => { setAnalysisPatient(null); setSelectedPatient(pid); setView('patients') }} onBack={analysisPatient ? () => { setAnalysisPatient(null); setView('patients') } : null} />
          ) : view === 'reports' ? (
            <ReportsView onViewScan={(id) => setSelectedScan(id)} />
          ) : view === 'analytics' ? (
            <AnalyticsView />
          ) : view === 'profile' ? (
            <ProfileView user={user} onUserUpdate={setUser} />
          ) : view === 'settings' ? (
            <SettingsView />
          ) : null}
        </main>
      </div>
    </div>
  )
}

export default App
