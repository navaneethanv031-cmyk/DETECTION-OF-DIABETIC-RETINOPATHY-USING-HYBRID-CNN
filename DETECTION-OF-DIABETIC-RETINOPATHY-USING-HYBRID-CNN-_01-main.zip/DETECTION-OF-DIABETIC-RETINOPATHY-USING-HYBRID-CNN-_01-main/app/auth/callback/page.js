'use client'

import { useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Loader2, Eye, AlertCircle } from 'lucide-react'

export default function AuthCallbackPage() {
  const router = useRouter()
  const params = useSearchParams()
  const [status, setStatus] = useState('Completing sign-in…')
  const [error, setError] = useState('')

  useEffect(() => {
    const sessionId = params.get('session_id')
    if (!sessionId) {
      setError('No session_id received from the identity provider. Please try signing in again.')
      return
    }

    fetch('/api/auth/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ session_id: sessionId }),
    })
      .then(async (res) => {
        const data = await res.json().catch(() => ({}))
        if (!res.ok) throw new Error(data.error || 'Sign-in failed')
        setStatus('Success — redirecting to your dashboard…')
        setTimeout(() => router.replace('/'), 500)
      })
      .catch((err) => setError(err.message))
  }, [params, router])

  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-teal-50 to-cyan-50 p-8">
      <div className="max-w-md w-full text-center bg-white rounded-2xl shadow-xl border border-slate-200 p-10">
        <div className="w-14 h-14 rounded-xl bg-teal-700 text-white flex items-center justify-center mx-auto mb-4">
          <Eye className="w-7 h-7" />
        </div>
        <div className="text-xl font-bold text-slate-900 mb-1">RetinaGuard</div>
        {error ? (
          <>
            <div className="mt-6 flex items-center justify-center gap-2 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-semibold">Sign-in failed</span>
            </div>
            <p className="text-sm text-slate-600 mt-2">{error}</p>
            <button onClick={() => router.replace('/')} className="mt-6 text-sm text-teal-700 font-semibold hover:underline">
              Return to sign-in
            </button>
          </>
        ) : (
          <>
            <div className="mt-6 flex items-center justify-center gap-2 text-slate-700">
              <Loader2 className="w-5 h-5 animate-spin text-teal-600" />
              <span className="font-medium">{status}</span>
            </div>
            <p className="text-xs text-slate-400 mt-4">Exchanging Emergent session · creating your clinician profile</p>
          </>
        )}
      </div>
    </main>
  )
}
